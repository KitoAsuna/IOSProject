//
//  MenuTableViewCell.h
//  FOSAapp1.0
//
//  Created by hs on 2019/12/30.
//  Copyright © 2019 hs. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MenuTableViewCell : UITableViewCell

@property (nonatomic,strong) UIImageView *categoryIcon;
@property (nonatomic,strong) UILabel *categoryTitle;

@end

NS_ASSUME_NONNULL_END
