//
//  foodItemCellXIB.h
//  FOSAapp1.0
//
//  Created by hs on 2020/3/24.
//  Copyright © 2020 hs. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface foodItemCellXIB : UICollectionViewCell

@end

NS_ASSUME_NONNULL_END
