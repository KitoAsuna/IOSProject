//
//  categoryCell.h
//  FOSAapp1.0
//
//  Created by hs on 2020/4/16.
//  Copyright © 2020 hs. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface categoryCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *categoryView;
@property (nonatomic,copy) NSString *imgName;
@end

NS_ASSUME_NONNULL_END
