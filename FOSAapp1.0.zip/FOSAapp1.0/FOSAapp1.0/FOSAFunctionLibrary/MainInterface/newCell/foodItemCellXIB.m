//
//  foodItemCellXIB.m
//  FOSAapp1.0
//
//  Created by hs on 2020/3/24.
//  Copyright © 2020 hs. All rights reserved.
//

#import "foodItemCellXIB.h"

@implementation foodItemCellXIB

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
