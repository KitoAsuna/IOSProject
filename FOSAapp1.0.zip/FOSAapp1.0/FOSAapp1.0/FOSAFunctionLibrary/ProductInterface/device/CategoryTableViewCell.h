//
//  CategoryTableViewCell.h
//  FOSAapp1.0
//
//  Created by hs on 2020/1/15.
//  Copyright © 2020 hs. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CategoryTableViewCell : UITableViewCell
@property (nonatomic,strong) UILabel *titleLable;
@property (nonatomic,strong) UIView *index;

@end

NS_ASSUME_NONNULL_END
