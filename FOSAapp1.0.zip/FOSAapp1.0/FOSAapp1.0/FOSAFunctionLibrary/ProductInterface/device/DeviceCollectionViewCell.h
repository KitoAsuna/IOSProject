//
//  DeviceCollectionViewCell.h
//  FOSAapp1.0
//
//  Created by hs on 2020/1/6.
//  Copyright © 2020 hs. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DeviceCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *productImageView;
@property (nonatomic,strong) UILabel *productName;
@end

NS_ASSUME_NONNULL_END
