//
//  resetAccountViewController.h
//  FOSAapp1.0
//
//  Created by hs on 2020/3/24.
//  Copyright © 2020 hs. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface resetAccountViewController : UIViewController
@property (nonatomic,strong) UIImageView *logoImageView;
@property (nonatomic,strong) UITextField *accountInput;
@property (nonatomic,strong) UIButton *doneBtn;
//@property (strong,nonatomic) UILabel *verificationLabel;
@end

NS_ASSUME_NONNULL_END
