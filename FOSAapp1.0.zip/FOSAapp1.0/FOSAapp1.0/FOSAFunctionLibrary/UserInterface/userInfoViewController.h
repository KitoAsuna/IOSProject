//
//  userInfoViewController.h
//  FOSAapp1.0
//
//  Created by hs on 2020/4/28.
//  Copyright © 2020 hs. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface userInfoViewController : UIViewController
@property (nonatomic,strong) UITableView *userInfoTable;
@property (nonatomic,strong) UIImageView *headIconView;
@property (nonatomic,strong) UIButton *logOutBtn;
@end

NS_ASSUME_NONNULL_END
