//
//  productCollectionViewCell.h
//  FOSA
//
//  Created by hs on 2019/12/29.
//  Copyright © 2019 hs. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface productCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *productImageView;
@end

NS_ASSUME_NONNULL_END
