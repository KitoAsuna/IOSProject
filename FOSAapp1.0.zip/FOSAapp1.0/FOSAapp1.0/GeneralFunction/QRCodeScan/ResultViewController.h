//
//  ResultViewController.h
//  FOSA
//
//  Created by hs on 2019/11/11.
//  Copyright © 2019 hs. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ResultViewController : UIViewController
@property (nonatomic,strong) UILabel *resultLabel;
@end

NS_ASSUME_NONNULL_END
