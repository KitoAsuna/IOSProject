//
//  foodKindView.h
//  FOSAapp1.0
//
//  Created by hs on 2020/3/8.
//  Copyright © 2020 hs. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface foodKindView : UIView
@property (nonatomic,strong) UILabel *kind;
@property (nonatomic,strong) UIImageView *categoryPhoto;
@property (nonatomic,strong) UIView *rootView;
@end

NS_ASSUME_NONNULL_END
