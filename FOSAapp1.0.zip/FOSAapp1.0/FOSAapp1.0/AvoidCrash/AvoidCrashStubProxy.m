//
//  AvoidCrashStubProxy.m
//  https://github.com/chenfanfang/AvoidCrash
//
//  Created by chenfanfang on 2017/7/25.
//  Copyright © 2017年 chenfanfang. All rights reserved.
//

#import "AvoidCrashStubProxy.h"


@implementation AvoidCrashStubProxy

- (void)proxyMethod {
    
}

@end
