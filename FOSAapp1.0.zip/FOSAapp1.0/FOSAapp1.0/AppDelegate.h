//
//  AppDelegate.h
//  FOSAapp1.0
//
//  Created by hs on 2019/12/29.
//  Copyright © 2019 hs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong,nonatomic) UIWindow *window;

@end

